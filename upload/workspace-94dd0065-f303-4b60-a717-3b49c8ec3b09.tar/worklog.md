# Project Worklog — Crystal Diagnostic Centre Website

## Project Brief
Premium 3D dynamic healthcare website for **Crystal Diagnostic Centre, Thane** (Uthalsar Naka, Thane West).
- Stack: Next.js 16 App Router, TypeScript, Tailwind 4, shadcn/ui, Prisma + SQLite, R3F/Three.js 3D.
- Phone: +91 8828393955. Address: 1,2, Shrikrishna Bhavan CHS, Opp. Varad Hospital, Uthalsar Naka, Uthalsar, Thane West, Thane, MH 400601.
- Colors: Navy #0B3B66, Medical Blue #087EA4, Teal #17B6A4, Soft BG #F4FAFC, Text #12304A, Muted #60788A, Border #DDEBF2.
- Font: Manrope (next/font). Logo: crystal "C" + medical cross + leaf (SVG system).
- **SANDBOX RULE**: only `/` route is user-visible → the entire site is a single-page app with hash-based routing (`#/about`, `#/services/...`, `#/admin`...). Do NOT create new files in `src/app/` besides metadata files.
- All sample/demo data must be clearly marked as demo. No invented certifications/prices claims. Demo notice bar on public site.

## Architecture Decisions
- Hash router via Zustand store (`src/lib/store.ts`) — routes: home, about, services, services/:slug, packages, packages/:slug, book-test, reports, contact, gallery, faq, privacy, terms, disclaimer, admin, 404.
- API under `src/app/api/**` (allowed). Auth: HMAC-signed httpOnly session cookie + scrypt password hashing (no extra deps). Rate limiting: in-memory sliding window.
- DB tables: SiteSetting(kv), ServiceCategory, Service, HealthPackage, PackageTest, AppointmentRequest, ContactMessage, Faq, GalleryImage, AdminUser, AuditLog.
- Default admin credentials seeded from env `ADMIN_USERNAME`/`ADMIN_PASSWORD` (fallback admin / Crystal@2024 — documented as demo, must change in production).

---
Task ID: 1a
Agent: Z.ai Code (lead)
Task: Foundation — deps, Prisma schema, seed, auth/security libs

Work Log:
- (in progress)

---
Task ID: 1a-1e (Foundation, complete)
Agent: Z.ai Code (lead)

Work Log:
- Installed three, @react-three/fiber@9, @react-three/drei@10, @types/three
- Prisma schema: SiteSetting(kv), ServiceCategory, Service, HealthPackage, PackageTest, AppointmentRequest, ContactMessage, Faq, GalleryImage, AdminUser, AuditLog → `bun run db:push` OK
- `bun prisma/seed.ts` → settings, admin (admin/Crystal@2024 demo), 5 categories, 12 services, 5 packages, 6 FAQs, 6 gallery images (DEMO data, priceVisible=false so prices hidden publicly)
- Libs: src/lib/{auth.ts (scrypt+HMAC session cookie), rate-limit.ts, constants.ts (BUSINESS info), settings.ts (DEFAULT_SETTINGS + parse), store.ts (hash router zustand), api-client.ts (api + DTO types), hooks.ts (React Query hooks), seo.ts (usePageMeta), audit.ts, perf.ts}
- APIs (all under src/app/api/**): settings GET/PUT, categories GET/POST + [id] PATCH/DELETE, services GET/POST + [slug] GET/PATCH/DELETE, packages same, appointments GET(admin)/POST(public, validated, rate-limited, honeypot) + [id], contact same, faqs, gallery, upload (sharp→webp ≤1600px), auth/{login,logout,me}, admin/stats, admin/export (CSV), audit-logs
- Brand: globals.css (palette tokens navy/medblue/teal/soft/ink/inkmuted/brandborder + utilities text-gradient-brand, glass-card, bg-med-grid, bg-radial-soft, eyebrow, scroll-area, card-lift), Manrope font in layout.tsx, full metadata + OG
- Logo system: src/components/brand/Logo.tsx (LogoMark/LogoHorizontal/LogoStacked, color|white themes), src/app/icon.svg, public/brand/{png,webp}, favicon.ico via scripts/generate-icons.mjs
- App shell: Providers (react-query), AppShell (hash sync, DemoNotice, admin=standalone chrome), Header (sticky glass, mobile Sheet drawer, phone + Book CTA), Footer (navy, 4 cols, legal, Staff Login link), FloatingActions (WhatsApp if configured, mobile call, back-to-top), RouteRenderer (lazy pages)
- 3D: three/Lazy3D.tsx (IO-lazy, reduced-motion skip, WebGL check, static fallback), three/HeroCrystal.tsx (crystal icosahedron shell w/ transmission on desktop, procedural molecule, particles, pointer rig, inline Lightformer env — no network fetch), three/DnaShowcase.tsx (DNA helix, scroll-boosted rotation)
- HomePage complete: hero (3D + CTAs + contact), trust strip, services preview (dynamic), featured packages (dynamic), why-choose-us (settings JSON), 3D science section, appointment CTA. Reveal helper for framer-motion whileInView. JSON-LD still to add per page.
- Shared: site/Shared.tsx → Breadcrumbs, PageHero, JsonLd, breadcrumbSchema
- Placeholder pages created for agent tasks; lint clean; GET / = 200; APIs verified

Stage Summary:
- Architecture: SPA at "/" with hash routes; admin at "#/admin" standalone
- API contracts in src/lib/api-client.ts (DTOs) — USE THESE TYPES
- Design tokens: bg-navy/medblue/teal/soft/ink/inkmuted/border-brandborder; brand classes above
- Images: scripts/generate-images.sh running in background → public/images/*.jpg (hero-fallback, og-image, cat-*, gallery-*, about-centre)
- DEMO compliance: DemoNotice banner (settings.demoNotice), priceVisible=false default, "sample data" notes inside seeded content
- Agent credentials note: admin/Crystal@2024 (env override ADMIN_USERNAME/ADMIN_PASSWORD)

---
Task ID: 2-a
Agent: full-stack-developer
Task: Public inner pages (About, Services, ServiceDetail, Packages, PackageDetail, Gallery, FAQ, Legal)

Work Log:
- Read worklog.md + all contract files (store.ts, api-client.ts, hooks.ts, settings.ts, constants.ts, seo.ts, site/Shared.tsx, brand/Logo.tsx, site/Reveal.tsx); verified API contracts via curl (/api/services, /api/packages, /api/categories include serviceCount, [slug] endpoints return 404 {error}).
- Created shared helpers in src/components/pages/:
  - PageStates.tsx → ErrorState (shadcn Alert + retry), EmptyState (dashed panel), CardsGridSkeleton, DetailSkeleton (2-col), CheckList (newline→Check icons), formatPrice (null/non-visible → "Price on request"), splitSentences, splitParagraphs.
  - ServiceCard.tsx → clickable/keyboard-accessible card (role=link, Enter/Space): category badge, line-clamp-2 shortDescription, Droplets sample-type + Clock turnaround row, price, Book (→#/book-test) + View Details buttons.
  - PackageCard.tsx → gradient header band (name + tests count + Featured badge), full test list (scroll-area when >8), price block, View Details + Book Now; whole card navigates to detail.
  - Lightbox.tsx → Dialog-based image viewer (index-controlled), ←/→ keyboard nav, Escape close, prev/next 44px buttons, counter, category badge; also exports FilterChip (aria-pressed pill with count) reused by Services + Gallery.
  - LegalPageLayout.tsx → shared legal layout: PageHero + Breadcrumbs + "Last updated: to be reviewed by the centre before launch." pill + max-w-3xl prose sections.
- AboutPage: settings-driven (aboutIntro/mission/vision/philosophy cards, facilities+quality CheckLists, "to be confirmed" values rendered visibly), /images/about-centre.jpg with "Representative image" caption, Visit Us strip (address, tel:+918828393955, workingHours + note, Get Directions window.open(BUSINESS.mapsDirections), Contact Us → #/contact). JSON-LD: breadcrumbSchema + MedicalBusiness (name/phone/address only — no unverifiable claims).
- ServicesPage: PageHero (settings.homeServicesIntro) + STICKY toolbar (top-16 md:top-[4.5rem]) with icon search (300ms debounce) + category chips w/ counts (server contract note: SQLite `contains` is case-sensitive, so search is debounced client-side case-insensitive; category still server-side via useServices({category})). "Showing X of Y" live region, clear-filters, empty/error states, Reveal grid of ServiceCard.
- ServiceDetailPage({slug}): DetailSkeleton loading; ApiError 404 → "Service not found" panel (Back to Services / Contact); 2-col layout — left: category badge, Popular tag, detailedDescription paragraphs (splitParagraphs), numbered Preparation callout (splitSentences, ClipboardList), sample-data footnote, related services (same categoryId, ≤3 mini cards) + View All; right lg:sticky top-24 sidebar: Request this Test → #/book-test, tel CTA, quick-facts dl (Sample/Report/Category with "To be confirmed" fallbacks), price row + "Pricing to be confirmed by the centre", medical-disclaimer Alert footnote. JSON-LD: breadcrumbs + Service schema (offers only when priceVisible; provider=MedicalBusiness).
- PackagesPage: PageHero (homePackagesIntro) + PackageCard grid + sample-data footnote; skeleton/empty/error states.
- PackageDetailPage({slug}): 404 panel, Tests Included numbered card (scroll-area >8), Preparation steps, "Who is this package for?" (applicability or "to be confirmed" default), Info Alert "Package contents are sample data pending confirmation by the centre", sticky sidebar (price row, Book Now → #/book-test, Call, back link).
- GalleryPage: PageHero + representative-imagery description, chips (All + GALLERY_CATEGORIES + any extra categories present, with counts), CSS-columns masonry (columns-2 sm:3 lg:4, break-inside-avoid, <img loading="lazy"> not next/image since URLs are dynamic), hover title/category overlay, Lightbox with keyboard nav; category change resets lightbox index; empty/loading/error states.
- FaqPage: live search Input (question+answer, case-insensitive), grouped by faq.category (fallback "General") with per-category Accordion (single collapsible) + count badges, "Still have questions?" CTA card (tel + Contact Us → #/contact). JSON-LD: breadcrumbSchema + FAQPage (all published Q&As).
- PrivacyPage/TermsPage/DisclaimerPage via LegalPageLayout: Privacy covers data collected (name/phone/email/appointment details via forms), purpose = contacting about requests, consent checkbox, no selling, retention ("to be confirmed"), cookie note (admin session cookie only, none for visitors), security advice (don't submit sensitive medical details), privacy-contact (address+phone). Terms covers lawful use, no medical advice, requests ≠ confirmed bookings, IP, liability, third-party links, governing law India / courts at Thane, Maharashtra. Disclaimer includes MEDICAL_DISCLAIMER verbatim in a highlighted "Official Disclaimer Statement" Alert plus supporting sections.
- Verification: bunx eslint src/components/pages/ → 0 problems; agent-browser smoke test of all routes: About/Services/Packages/Gallery/FAQ/legal render, titles update via usePageMeta (e.g. "Diagnostic Services | Crystal Diagnostic Centre"), services search 12→1 for "lipid", Radiology chip 2/12, clear filters 12/12, ServiceDetail + PackageDetail render w/ Related/Tests, both 404 panels OK, lightbox open→ArrowRight→Escape OK, FAQ search OK, mobile 390px renders 5 package cards; curl / → 200; dev.log shows only stale (pre-existing) module-not-found entries and expected /images/*.jpg 404s (image-gen script still pending from Task 1).

Stage Summary:
- All 10 inner pages implemented at exact contract paths; new helpers: pages/{PageStates,ServiceCard,PackageCard,Lightbox,LegalPageLayout}.tsx. No files outside pages/ touched; store/hooks/Shared untouched.
- Navigation rule honoured: all navigation via useRouterStore.navigate("#/..."), zero next/link. Detail pages receive `slug` prop (matches RouteRenderer).
- Prices: never rendered unless priceVisible && price!=null → "Price on request" + "Pricing to be confirmed by the centre" note on detail sidebars. No invented certifications/stats; sample-data notes surfaced (PackagesPage footnote, PackageDetail Info card, Gallery footer note).
- DECISION: services text search filters client-side (debounced 300ms, case-insensitive) because SQLite Prisma `contains` is case-sensitive; the useServices({search}) param remains available for future use. Category filtering stays server-side.
- KNOWN ISSUE (lead's scope): document.title set by usePageMeta can be reverted by React 19 head-hydration on FIRST load (canonical/meta do persist); on any hash navigation titles apply correctly. Also lint errors exist in src/components/admin/* + unused-disable warning in site/Shared.tsx — owned by other agents, left untouched.
- public/images/* are still pending from Task 1's background script; pages reference /images/about-centre.jpg and gallery URLs from DB and will light up once those land.
