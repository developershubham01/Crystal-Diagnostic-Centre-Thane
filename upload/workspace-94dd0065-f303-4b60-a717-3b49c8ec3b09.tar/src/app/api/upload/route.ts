import { NextRequest, NextResponse } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/auth";
import { rateLimit, getClientIp } from "@/lib/rate-limit";
import { logAudit } from "@/lib/audit";
import sharp from "sharp";

const MAX_BYTES = 6 * 1024 * 1024; // 6 MB
const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/svg+xml"];

/**
 * POST /api/upload — admin image upload.
 * Images are compressed and resized (max 1600px wide) with sharp, then stored
 * under /public/uploads. SVGs are sanitised lightly (no script tags) and stored as-is.
 */
export async function POST(req: NextRequest) {
  const session = verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const rl = rateLimit(`upload:${getClientIp(req)}`, 30, 10 * 60_000);
  if (!rl.allowed) return NextResponse.json({ error: "Too many uploads. Try later." }, { status: 429 });

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "No file provided" }, { status: 400 });
  }
  if (!ALLOWED.includes(file.type)) {
    return NextResponse.json({ error: "Only JPG, PNG, WebP or SVG images are allowed" }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: "File too large (max 6 MB)" }, { status: 400 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const stamp = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 8);

  let filename: string;
  const uploadsDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadsDir, { recursive: true });

  if (file.type === "image/svg+xml") {
    const svg = buffer.toString("utf8").replace(/<script[\s\S]*?<\/script>/gi, "").replace(/on\w+="[^"]*"/gi, "");
    filename = `${stamp}-${rand}.svg`;
    await writeFile(path.join(uploadsDir, filename), svg, "utf8");
  } else {
    filename = `${stamp}-${rand}.webp`;
    const webp = await sharp(buffer)
      .rotate()
      .resize({ width: 1600, withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer();
    await writeFile(path.join(uploadsDir, filename), webp);
  }

  await logAudit(db, session, "UPLOAD", "image", filename, null);

  return NextResponse.json({ url: `/uploads/${filename}` }, { status: 201 });
}
