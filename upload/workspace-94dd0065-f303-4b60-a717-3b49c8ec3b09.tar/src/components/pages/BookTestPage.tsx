"use client";

import { useMemo, useState } from "react";
import {
  CalendarCheck,
  CheckCircle2,
  Clock,
  Home,
  Info,
  MapPin,
  Phone,
  Send,
  ShieldCheck,
  Loader2,
} from "lucide-react";
import { api, ApiError } from "@/lib/api-client";
import { usePageMeta } from "@/lib/seo";
import { useSettings } from "@/lib/hooks";
import { useRouterStore } from "@/lib/store";
import { useServices, usePackages } from "@/lib/hooks";
import { BUSINESS } from "@/lib/constants";
import { Breadcrumbs, JsonLd, PageHero, breadcrumbSchema, type Crumb } from "@/components/site/Shared";
import { Reveal } from "@/components/site/Reveal";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

const CRUMBS: Crumb[] = [{ label: "Book a Test" }];

const TIME_SLOTS = [
  "Morning (7:00 AM – 11:00 AM)",
  "Midday (11:00 AM – 2:00 PM)",
  "Afternoon (2:00 PM – 5:00 PM)",
  "Evening (5:00 PM – 9:00 PM)",
];

const OTHER_OPTION = "__other__";

interface FormState {
  name: string;
  mobile: string;
  email: string;
  testValue: string;
  preferredDate: string;
  preferredTime: string;
  homeCollection: boolean;
  message: string;
  consent: boolean;
  website: string; // honeypot — must stay empty
}

const INITIAL_FORM: FormState = {
  name: "",
  mobile: "",
  email: "",
  testValue: "",
  preferredDate: "",
  preferredTime: "",
  homeCollection: false,
  message: "",
  consent: false,
  website: "",
};

type FormErrors = Partial<Record<keyof FormState, string>>;

/** Normalise an Indian mobile number to bare 10 digits (accepts +91 / 91 / 0 prefixes). */
function normaliseMobile(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 12 && digits.startsWith("91")) return digits.slice(2);
  if (digits.length === 11 && digits.startsWith("0")) return digits.slice(1);
  return digits;
}

function todayIso(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function FieldError({ id, message }: { id: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} role="alert" className="mt-1.5 text-xs font-medium text-destructive">
      {message}
    </p>
  );
}

export function BookTestPage() {
  usePageMeta("Book a Test", "Request an appointment at Crystal Diagnostic Centre, Thane. Our team will contact you to confirm your test, date and time.", "/book-test");
  const { toast } = useToast();
  const navigate = useRouterStore((s) => s.navigate);
  const { data: settings } = useSettings();
  const { data: services = [] } = useServices();
  const { data: packages = [] } = usePackages();

  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const minDate = useMemo(todayIso, []);

  // value -> display label for the test/package dropdown
  const testOptions = useMemo(() => {
    const map = new Map<string, string>();
    for (const s of services) map.set(`service:${s.slug}`, s.name);
    for (const p of packages) map.set(`package:${p.slug}`, p.name);
    map.set(OTHER_OPTION, "Other (specify in message)");
    return map;
  }, [services, packages]);

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => (e[key] ? { ...e, [key]: undefined } : e));
  }

  function validate(): FormErrors {
    const errs: FormErrors = {};
    if (form.name.trim().length < 2) errs.name = "Please enter your full name.";
    const mobile = normaliseMobile(form.mobile);
    if (!/^[6-9]\d{9}$/.test(mobile)) errs.mobile = "Enter a valid 10-digit Indian mobile number.";
    if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      errs.email = "Enter a valid email address (or leave it blank).";
    }
    if (!form.testValue) errs.testValue = "Please choose a test, package, or 'Other'.";
    if (form.message.length > 2000) errs.message = "Message is too long (max 2000 characters).";
    if (!form.consent) errs.consent = "Please provide consent so our team can contact you.";
    return errs;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setApiError(null);
    const errs = validate();
    setErrors(errs);
    if (Object.values(errs).some(Boolean)) {
      const first = Object.keys(errs).find((k) => errs[k as keyof FormErrors]);
      document.getElementById(`book-${first}`)?.focus();
      return;
    }

    setSubmitting(true);
    try {
      const label = testOptions.get(form.testValue) ?? form.testValue;
      await api.post("/api/appointments", {
        name: form.name.trim(),
        mobile: normaliseMobile(form.mobile),
        email: form.email.trim() || undefined,
        testOrPackage: label,
        preferredDate: form.preferredDate || undefined,
        preferredTime: form.preferredTime || undefined,
        homeCollection: form.homeCollection,
        message: form.message.trim() || undefined,
        consent: form.consent,
        website: form.website, // honeypot — always empty for humans
      });
      setSubmitted(true);
      toast({
        title: "Request received",
        description: "Our team will contact you to confirm the details.",
      });
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Something went wrong. Please try again.";
      setApiError(message);
      if (!(err instanceof ApiError && err.status === 429)) {
        toast({ title: "Could not send request", description: message, variant: "destructive" });
      }
    } finally {
      setSubmitting(false);
    }
  }

  function resetForm() {
    setForm(INITIAL_FORM);
    setErrors({});
    setApiError(null);
    setSubmitted(false);
  }

  const showHomeCollection = settings.homeCollectionAvailable !== "no";

  return (
    <>
      <JsonLd data={breadcrumbSchema(CRUMBS)} />
      <PageHero
        eyebrow="Appointments"
        title="Book a Test"
        description="Tell us which test or health package you need and when you would like to visit. This is an appointment request — our team confirms every slot personally."
      >
        <div className="mt-6">
          <Breadcrumbs items={CRUMBS} />
        </div>
      </PageHero>

      <section className="bg-soft/40">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
          <Reveal>
            <Card className="rounded-2xl border-brandborder bg-white/80 p-0">
              <CardContent className="flex items-start gap-3 p-5">
                <Info className="mt-0.5 h-5 w-5 shrink-0 text-medblue" aria-hidden />
                <div>
                  <p className="text-sm font-semibold text-navy">Before you submit</p>
                  <p className="mt-1 text-sm leading-relaxed text-inkmuted">{settings.bookTestNote}</p>
                  <p className="mt-1 text-xs leading-relaxed text-inkmuted">
                    Please do not share sensitive medical details in this form — test selection and preparation
                    guidance are confirmed over the phone.
                  </p>
                </div>
              </CardContent>
            </Card>
          </Reveal>

          <div className="mt-8 grid gap-6 lg:grid-cols-3">
            {/* ------------ Form / success ------------ */}
            <Reveal className="lg:col-span-2" delay={0.05}>
              {submitted ? (
                <Card className="glass-card rounded-2xl p-0 text-center">
                  <CardContent className="flex flex-col items-center gap-4 p-8 sm:p-12">
                    <span className="flex h-16 w-16 items-center justify-center rounded-full bg-teal-soft/60">
                      <CheckCircle2 className="h-9 w-9 text-teal" aria-hidden />
                    </span>
                    <h2 className="text-xl font-extrabold text-navy sm:text-2xl">
                      Thank you. Your appointment request has been received.
                      <span className="block">Our team will contact you to confirm the details.</span>
                    </h2>
                    <p className="max-w-md text-sm leading-relaxed text-inkmuted">
                      Requests are typically confirmed during centre working hours. If your test is time-sensitive,
                      you can call us directly at{" "}
                      <a href={BUSINESS.phoneHref} className="font-semibold text-medblue hover:underline">
                        {BUSINESS.phoneDisplay}
                      </a>
                      .
                    </p>
                    <div className="mt-2 flex flex-wrap justify-center gap-3">
                      <Button variant="outline" className="rounded-xl" onClick={() => navigate("#/")}>
                        <Home className="h-4 w-4" aria-hidden />
                        Back to Home
                      </Button>
                      <Button className="rounded-xl" onClick={resetForm}>
                        <CalendarCheck className="h-4 w-4" aria-hidden />
                        Book Another Test
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="rounded-2xl border-brandborder p-0">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg font-extrabold text-navy">Appointment request form</CardTitle>
                    <p className="text-sm text-inkmuted">
                      Fields marked <span aria-hidden>*</span><span className="sr-only">asterisk</span> are required.
                    </p>
                  </CardHeader>
                  <CardContent className="p-5 pt-2 sm:p-6 sm:pt-2">
                    {apiError && (
                      <div
                        role="alert"
                        className="mb-5 rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm font-medium text-destructive"
                      >
                        {apiError}
                      </div>
                    )}

                    <form noValidate onSubmit={handleSubmit} className="space-y-5">
                      {/* Honeypot — hidden from humans, traps bots */}
                      <div className="hidden" aria-hidden="true">
                        <label htmlFor="book-website">Website</label>
                        <input
                          id="book-website"
                          type="text"
                          name="website"
                          tabIndex={-1}
                          autoComplete="off"
                          value={form.website}
                          onChange={(e) => set("website", e.target.value)}
                        />
                      </div>

                      <div className="grid gap-5 sm:grid-cols-2">
                        <div>
                          <Label htmlFor="book-name">
                            Full Name <span aria-hidden>*</span>
                          </Label>
                          <Input
                            id="book-name"
                            type="text"
                            autoComplete="name"
                            placeholder="e.g. Priya Sharma"
                            value={form.name}
                            onChange={(e) => set("name", e.target.value)}
                            aria-invalid={!!errors.name}
                            aria-describedby={errors.name ? "book-name-error" : undefined}
                            className="mt-1.5 rounded-xl"
                          />
                          <FieldError id="book-name-error" message={errors.name} />
                        </div>

                        <div>
                          <Label htmlFor="book-mobile">
                            Mobile Number <span aria-hidden>*</span>
                          </Label>
                          <div className="mt-1.5 flex items-stretch gap-2">
                            <span className="inline-flex select-none items-center rounded-xl border border-input bg-soft px-3 text-sm font-semibold text-navy">
                              +91
                            </span>
                            <Input
                              id="book-mobile"
                              type="tel"
                              inputMode="numeric"
                              autoComplete="tel-national"
                              placeholder="98765 43210"
                              value={form.mobile}
                              onChange={(e) => set("mobile", e.target.value)}
                              aria-invalid={!!errors.mobile}
                              aria-describedby={errors.mobile ? "book-mobile-error" : undefined}
                              className="rounded-xl"
                            />
                          </div>
                          <FieldError id="book-mobile-error" message={errors.mobile} />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="book-email">Email (optional)</Label>
                        <Input
                          id="book-email"
                          type="email"
                          autoComplete="email"
                          placeholder="you@example.com"
                          value={form.email}
                          onChange={(e) => set("email", e.target.value)}
                          aria-invalid={!!errors.email}
                          aria-describedby={errors.email ? "book-email-error" : undefined}
                          className="mt-1.5 rounded-xl"
                        />
                        <FieldError id="book-email-error" message={errors.email} />
                      </div>

                      <div>
                        <Label htmlFor="book-test">
                          Test or Package <span aria-hidden>*</span>
                        </Label>
                        <Select value={form.testValue} onValueChange={(v) => set("testValue", v)}>
                          <SelectTrigger
                            id="book-test"
                            aria-invalid={!!errors.testValue}
                            aria-describedby={errors.testValue ? "book-test-error" : undefined}
                            className="mt-1.5 w-full rounded-xl"
                          >
                            <SelectValue placeholder="Select a test, package, or Other" />
                          </SelectTrigger>
                          <SelectContent className="max-h-72">
                            <SelectGroup>
                              <SelectLabel>Services</SelectLabel>
                              {services.length === 0 && (
                                <SelectItem value="__no_services__" disabled>
                                  Loading services…
                                </SelectItem>
                              )}
                              {services.map((s) => (
                                <SelectItem key={s.slug} value={`service:${s.slug}`}>
                                  {s.name}
                                </SelectItem>
                              ))}
                            </SelectGroup>
                            <SelectGroup>
                              <SelectLabel>Health Packages</SelectLabel>
                              {packages.map((p) => (
                                <SelectItem key={p.slug} value={`package:${p.slug}`}>
                                  {p.name}
                                </SelectItem>
                              ))}
                            </SelectGroup>
                            <SelectGroup>
                              <SelectLabel>Other</SelectLabel>
                              <SelectItem value={OTHER_OPTION}>Other (specify in message)</SelectItem>
                            </SelectGroup>
                          </SelectContent>
                        </Select>
                        <FieldError id="book-test-error" message={errors.testValue} />
                      </div>

                      <div className="grid gap-5 sm:grid-cols-2">
                        <div>
                          <Label htmlFor="book-date">Preferred Date</Label>
                          <Input
                            id="book-date"
                            type="date"
                            min={minDate}
                            value={form.preferredDate}
                            onChange={(e) => set("preferredDate", e.target.value)}
                            className="mt-1.5 rounded-xl"
                          />
                          <p className="mt-1.5 text-xs text-inkmuted">Optional — final slot is confirmed by phone.</p>
                        </div>
                        <div>
                          <Label htmlFor="book-time">Preferred Time</Label>
                          <Select value={form.preferredTime} onValueChange={(v) => set("preferredTime", v)}>
                            <SelectTrigger id="book-time" className="mt-1.5 w-full rounded-xl">
                              <SelectValue placeholder="Any time (we will confirm)" />
                            </SelectTrigger>
                            <SelectContent>
                              {TIME_SLOTS.map((slot) => (
                                <SelectItem key={slot} value={slot}>
                                  {slot}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {showHomeCollection && (
                        <div className="rounded-xl border border-brandborder bg-soft/60 p-4">
                          <label
                            htmlFor="book-homecollection"
                            className="flex cursor-pointer items-start gap-3 text-sm font-medium text-ink"
                          >
                            <Checkbox
                              id="book-homecollection"
                              checked={form.homeCollection}
                              onCheckedChange={(v) => set("homeCollection", v === true)}
                              className="mt-0.5"
                            />
                            <span>
                              Request home sample collection
                              {settings.homeCollectionAvailable === "tbc" && (
                                <span className="mt-1 block text-xs font-normal text-inkmuted">
                                  Subject to availability — our team will confirm.
                                </span>
                              )}
                            </span>
                          </label>
                        </div>
                      )}

                      <div>
                        <Label htmlFor="book-message">Message</Label>
                        <Textarea
                          id="book-message"
                          rows={4}
                          placeholder="Any details that help us prepare — e.g. doctor's reference, preferred language, questions about preparation."
                          value={form.message}
                          onChange={(e) => set("message", e.target.value)}
                          aria-invalid={!!errors.message}
                          aria-describedby={errors.message ? "book-message-error" : "book-message-hint"}
                          className="mt-1.5 rounded-xl"
                        />
                        <p id="book-message-hint" className="mt-1.5 text-xs text-inkmuted">
                          Optional. Please avoid sharing sensitive medical information here.
                        </p>
                        <FieldError id="book-message-error" message={errors.message} />
                      </div>

                      <div className="rounded-xl border border-brandborder bg-soft/60 p-4">
                        <label
                          htmlFor="book-consent"
                          className="flex cursor-pointer items-start gap-3 text-sm font-medium text-ink"
                        >
                          <Checkbox
                            id="book-consent"
                            checked={form.consent}
                            onCheckedChange={(v) => set("consent", v === true)}
                            aria-invalid={!!errors.consent}
                            aria-describedby={errors.consent ? "book-consent-error" : undefined}
                            className="mt-0.5"
                          />
                          <span>
                            I agree to be contacted by Crystal Diagnostic Centre regarding this request.{" "}
                            <span aria-hidden>*</span>
                          </span>
                        </label>
                        <FieldError id="book-consent-error" message={errors.consent} />
                      </div>

                      <Button
                        type="submit"
                        size="lg"
                        disabled={submitting}
                        className="w-full rounded-xl sm:w-auto sm:px-8"
                      >
                        {submitting ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                            Sending request…
                          </>
                        ) : (
                          <>
                            <Send className="h-4 w-4" aria-hidden />
                            Send Appointment Request
                          </>
                        )}
                      </Button>
                      <p className="text-xs leading-relaxed text-inkmuted">
                        This form sends a <strong>request</strong> only — slots are confirmed by our team over the
                        phone. No payment is collected online.
                      </p>
                    </form>
                  </CardContent>
                </Card>
              )}
            </Reveal>

            {/* ------------ Sidebar ------------ */}
            <div className="space-y-6">
              <Reveal delay={0.1}>
                <Card className="rounded-2xl border-brandborder p-0">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-extrabold text-navy">Contact & visiting</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 p-5 pt-0">
                    <div className="flex items-start gap-3">
                      <Phone className="mt-0.5 h-4.5 w-4.5 shrink-0 text-medblue" aria-hidden />
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wide text-inkmuted">Phone</p>
                        <a
                          href={BUSINESS.phoneHref}
                          className="text-sm font-semibold text-navy transition-colors hover:text-medblue"
                        >
                          {settings.phone || BUSINESS.phoneDisplay}
                        </a>
                      </div>
                    </div>
                    <Separator className="bg-brandborder" />
                    <div className="flex items-start gap-3">
                      <MapPin className="mt-0.5 h-4.5 w-4.5 shrink-0 text-medblue" aria-hidden />
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wide text-inkmuted">Address</p>
                        <p className="whitespace-pre-line text-sm leading-relaxed text-ink">{settings.address}</p>
                      </div>
                    </div>
                    <Separator className="bg-brandborder" />
                    <div className="flex items-start gap-3">
                      <Clock className="mt-0.5 h-4.5 w-4.5 shrink-0 text-medblue" aria-hidden />
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wide text-inkmuted">Working Hours</p>
                        <p className="whitespace-pre-line text-sm leading-relaxed text-ink">{settings.workingHours}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Reveal>

              <Reveal delay={0.15}>
                <Card className="rounded-2xl border-teal-soft bg-white p-0">
                  <CardContent className="flex items-start gap-3 p-5">
                    <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-teal" aria-hidden />
                    <div>
                      <p className="text-sm font-bold text-navy">No online payment</p>
                      <p className="mt-1 text-xs leading-relaxed text-inkmuted">
                        Booking a test on this website is free. Payments, if applicable, are collected only at the
                        centre after your visit is confirmed.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </Reveal>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
