"use client";

import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  CalendarCheck,
  ClipboardCheck,
  HeartHandshake,
  MapPin,
  Phone,
  ShieldCheck,
  FlaskConical,
  Microscope,
  ScanLine,
  Droplets,
  Stethoscope,
  Sparkles,
  Clock,
  FileCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { LogoMark } from "@/components/brand/Logo";
import { Lazy3D, loadHeroCrystal, loadDnaShowcase } from "@/components/three/Lazy3D";
import { Reveal } from "@/components/site/Reveal";
import { useRoute, useRouterStore } from "@/lib/store";
import { useSettings, useCategories, usePackages } from "@/lib/hooks";
import { parseWhyChooseUs } from "@/lib/settings";
import { usePageMeta } from "@/lib/seo";
import { useIsMobile } from "@/hooks/use-mobile";
import { BUSINESS } from "@/lib/constants";

const CATEGORY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Droplets,
  Microscope,
  ScanLine,
  HeartPulse: HeartHandshake,
  Stethoscope,
  FlaskConical,
};

function formatPrice(price: number | null, visible: boolean) {
  if (!visible || price === null) return "Price on request";
  return `₹${price.toLocaleString("en-IN")}`;
}

export function HomePage() {
  const navigate = useRouterStore((s) => s.navigate);
  const route = useRoute();
  const { data: settings } = useSettings();
  const { data: categories, isLoading: catsLoading } = useCategories();
  const { data: packages, isLoading: pkgsLoading } = usePackages({ featured: true });
  const isMobile = useIsMobile() ?? false;
  const whyItems = parseWhyChooseUs(settings.whyChooseUs).slice(0, 4);
  usePageMeta("", settings.seoDescription, "/");

  const go = (hash: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    navigate(hash);
  };

  const trustCards = [
    {
      icon: CalendarCheck,
      title: "Convenient Appointment Requests",
      text: "Request a test slot online in under a minute — our team confirms the details with you by phone.",
    },
    {
      icon: ClipboardCheck,
      title: "Transparent Test Information",
      text: "Clear preparation instructions and test details, so you arrive ready and confident.",
    },
    {
      icon: HeartHandshake,
      title: "Patient-Focused Service",
      text: "A caring front-desk team that takes time to answer your questions without rushing.",
    },
    {
      icon: MapPin,
      title: "Easy Location Access",
      text: "Opposite Varad Hospital at Uthalsar Naka — easy to reach from across Thane West.",
    },
  ];

  const sciencePoints = [
    {
      icon: ShieldCheck,
      title: "Careful Process",
      text: "Sample labelling, handling and verification at every step.",
    },
    {
      icon: Clock,
      title: "Timely Reporting",
      text: "Clear turnaround expectations communicated upfront.",
    },
    {
      icon: FileCheck,
      title: "Doctor-Friendly Reports",
      text: "Organised, readable reports your doctor can act on.",
    },
  ];

  return (
    <div className="bg-white">
      {/* ============================ HERO ============================ */}
      <section className="bg-radial-soft relative overflow-hidden" aria-labelledby="hero-heading">
        <div className="bg-med-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(75%_60%_at_50%_35%,black,transparent)]" aria-hidden />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-2 lg:gap-6 lg:pb-24 lg:pt-20 xl:gap-12 lg:px-8">
          {/* Copy */}
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 rounded-full border border-brandborder bg-white/80 px-3.5 py-1.5 shadow-sm backdrop-blur"
            >
              <LogoMark className="h-5 w-5" />
              <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-medblue sm:text-xs">
                Welcome to {settings.businessName}, Thane
              </span>
            </motion.div>

            <motion.h1
              id="hero-heading"
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.08 }}
              className="mt-5 text-4xl font-extrabold leading-[1.08] tracking-tight text-navy sm:text-5xl xl:text-[3.4rem]"
            >
              {settings.heroHeadline.split(" ").slice(0, -2).join(" ")}{" "}
              <span className="text-gradient-brand">
                {settings.heroHeadline.split(" ").slice(-2).join(" ")}
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.16 }}
              className="mt-5 text-[15px] leading-relaxed text-inkmuted sm:text-base"
            >
              {settings.heroSubheadline}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.24 }}
              className="mt-7 flex flex-wrap items-center gap-3"
            >
              <Button
                onClick={go("#/book-test")}
                className="h-12 rounded-full bg-gradient-to-r from-navy to-medblue px-7 text-[15px] font-bold text-white shadow-lg shadow-navy/25 transition-transform hover:scale-[1.03]"
              >
                <CalendarCheck className="mr-2 h-5 w-5" aria-hidden />
                Book a Test
              </Button>
              <Button
                variant="outline"
                onClick={go("#/services")}
                className="h-12 rounded-full border-medblue/40 px-6 text-[15px] font-bold text-navy hover:bg-white"
              >
                Explore Services
                <ArrowRight className="ml-1.5 h-4 w-4" aria-hidden />
              </Button>
              <Button
                variant="ghost"
                onClick={go("#/contact")}
                className="h-12 rounded-full px-5 text-[15px] font-bold text-medblue hover:bg-white/70"
              >
                Contact Centre
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm"
            >
              <a
                href={BUSINESS.phoneHref}
                className="group inline-flex items-center gap-2.5 font-bold text-navy"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-md shadow-navy/10 ring-1 ring-brandborder transition-transform group-hover:scale-105">
                  <Phone className="h-4.5 w-4.5 text-teal" aria-hidden />
                </span>
                {settings.phone}
              </a>
              <span className="hidden h-6 w-px bg-brandborder sm:block" aria-hidden />
              <span className="inline-flex items-center gap-2 text-inkmuted">
                <MapPin className="h-4 w-4 text-medblue" aria-hidden />
                {BUSINESS.addressShort}
              </span>
            </motion.div>
          </div>

          {/* 3D visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative mx-auto w-full max-w-[540px]"
          >
            <div
              className="absolute left-1/2 top-1/2 -z-10 h-[115%] w-[115%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-teal/15 via-transparent to-medblue/15 blur-2xl"
              aria-hidden
            />
            <Lazy3D
              load={loadHeroCrystal}
              fallbackSrc="/images/hero-fallback.jpg"
              fallbackAlt="Abstract crystal with molecular structure (static preview)"
              className="aspect-square w-full"
              minHeight={340}
              sceneProps={{ mobile: isMobile }}
              hint="Interactive 3D — drag to rotate"
            />
          </motion.div>
        </div>

        {/* marquee-free trust strip */}
        <div className="relative border-t border-brandborder/70 bg-white/70 backdrop-blur">
          <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-brandborder/60 sm:grid-cols-4">
            {[
              { label: "Appointment Requests", sub: "Online & by phone" },
              { label: "Clear Preparation", sub: "Step-by-step guidance" },
              { label: "Neighbourhood Care", sub: "At Uthalsar Naka" },
              { label: "Sample Data Marked", sub: "Verified before launch" },
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center gap-0.5 px-3 py-4 text-center">
                <span className="text-[13px] font-bold text-navy">{item.label}</span>
                <span className="text-[11px] text-inkmuted">{item.sub}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ==================== TRUST & CONVENIENCE ==================== */}
      <section className="bg-soft py-16 sm:py-20" aria-labelledby="trust-heading">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="eyebrow">Why Patients Choose Us</p>
            <h2 id="trust-heading" className="mt-2 text-3xl font-extrabold tracking-tight text-navy sm:text-[2.1rem]">
              Care that starts before your test
            </h2>
            <p className="mt-3 text-[15px] leading-relaxed text-inkmuted">
              Simple conveniences that make your diagnostic visit smooth — verified information only, no exaggerated claims.
            </p>
          </Reveal>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {trustCards.map((card, i) => (
              <Reveal key={card.title} delay={i * 0.08}>
                <div className="card-lift group h-full rounded-2xl border border-brandborder bg-white p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-medblue/10 to-teal/10 ring-1 ring-brandborder transition-transform group-hover:scale-105">
                    <card.icon className="h-6 w-6 text-medblue" aria-hidden />
                  </div>
                  <h3 className="mt-4 text-[15px] font-extrabold text-navy">{card.title}</h3>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-inkmuted">{card.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ==================== SERVICES PREVIEW ==================== */}
      <section className="py-16 sm:py-20" aria-labelledby="services-heading">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
            <Reveal className="max-w-xl">
              <p className="eyebrow">Our Services</p>
              <h2 id="services-heading" className="mt-2 text-3xl font-extrabold tracking-tight text-navy sm:text-[2.1rem]">
                Diagnostic service categories
              </h2>
              <p className="mt-3 text-[15px] leading-relaxed text-inkmuted">{settings.homeServicesIntro}</p>
            </Reveal>
            <Reveal delay={0.1}>
              <Button
                variant="outline"
                onClick={go("#/services")}
                className="rounded-full border-medblue/40 font-bold text-navy"
              >
                View All Services <ArrowRight className="ml-1.5 h-4 w-4" aria-hidden />
              </Button>
            </Reveal>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
            {catsLoading &&
              [0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
            {!catsLoading &&
              (categories ?? []).slice(0, 5).map((cat, i) => {
                const Icon = CATEGORY_ICONS[cat.icon ?? ""] ?? FlaskConical;
                return (
                  <Reveal key={cat.id} delay={i * 0.06}>
                    <button
                      onClick={go("#/services")}
                      className="card-lift group h-full w-full rounded-2xl border border-brandborder bg-white p-6 text-left"
                      aria-label={`View ${cat.name}`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-navy/5 ring-1 ring-brandborder transition-colors group-hover:bg-navy">
                          <Icon className="h-5.5 w-5.5 text-medblue transition-colors group-hover:text-teal-soft" aria-hidden />
                        </div>
                        <span className="rounded-full bg-soft px-2.5 py-1 text-[11px] font-bold text-medblue">
                          {cat.serviceCount ?? 0} {cat.serviceCount === 1 ? "test" : "tests"}
                        </span>
                      </div>
                      <h3 className="mt-4 text-[15.5px] font-extrabold text-navy">{cat.name}</h3>
                      <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-inkmuted">
                        {cat.description}
                      </p>
                      <span className="mt-3 inline-flex items-center gap-1 text-[13px] font-bold text-medblue opacity-0 transition-opacity group-hover:opacity-100">
                        Learn more <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                      </span>
                    </button>
                  </Reveal>
                );
              })}
          </div>
        </div>
      </section>

      {/* ==================== FEATURED PACKAGES ==================== */}
      <section className="bg-soft py-16 sm:py-20" aria-labelledby="packages-heading">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="eyebrow">Health Packages</p>
            <h2 id="packages-heading" className="mt-2 text-3xl font-extrabold tracking-tight text-navy sm:text-[2.1rem]">
              Preventive check-ups, thoughtfully bundled
            </h2>
            <p className="mt-3 text-[15px] leading-relaxed text-inkmuted">{settings.homePackagesIntro}</p>
          </Reveal>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {pkgsLoading &&
              [0, 1, 2].map((i) => <Skeleton key={i} className="h-72 rounded-2xl" />)}
            {!pkgsLoading &&
              (packages ?? []).slice(0, 3).map((pkg, i) => (
                <Reveal key={pkg.id} delay={i * 0.08}>
                  <div className="card-lift flex h-full flex-col rounded-2xl border border-brandborder bg-white">
                    <div className="relative flex items-center justify-between border-b border-brandborder bg-gradient-to-r from-navy to-medblue p-5 text-white">
                      <div>
                        <h3 className="text-lg font-extrabold">{pkg.name}</h3>
                        <p className="mt-0.5 text-xs text-white/80">
                          {pkg.tests.length} {pkg.tests.length === 1 ? "test" : "tests"} included
                        </p>
                      </div>
                      <Sparkles className="h-7 w-7 text-teal-soft" aria-hidden />
                    </div>
                    <div className="flex-1 p-5">
                      <p className="text-[13.5px] leading-relaxed text-inkmuted">{pkg.description}</p>
                      <ul className="mt-4 space-y-2">
                        {pkg.tests.slice(0, 4).map((t) => (
                          <li key={t.id} className="flex items-center gap-2 text-[13px] font-medium text-ink">
                            <span className="h-1.5 w-1.5 rounded-full bg-teal" aria-hidden />
                            {t.name}
                          </li>
                        ))}
                        {pkg.tests.length > 4 && (
                          <li className="text-[13px] font-semibold text-medblue">
                            + {pkg.tests.length - 4} more tests
                          </li>
                        )}
                      </ul>
                    </div>
                    <div className="flex items-center justify-between border-t border-brandborder p-5">
                      <div>
                        <span className="text-[11px] uppercase tracking-wide text-inkmuted">Package price</span>
                        <p className="text-lg font-extrabold text-navy">{formatPrice(pkg.price, pkg.priceVisible)}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={go(`#/packages/${pkg.slug}`)}
                          className="rounded-full border-brandborder font-bold text-navy"
                        >
                          Details
                        </Button>
                        <Button
                          size="sm"
                          onClick={go("#/book-test")}
                          className="rounded-full bg-gradient-to-r from-navy to-medblue font-bold text-white"
                        >
                          Book Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            {!pkgsLoading && (packages ?? []).length === 0 && (
              <p className="col-span-full rounded-2xl border border-dashed border-brandborder bg-white p-8 text-center text-sm text-inkmuted">
                Health packages will appear here once published by the centre.
              </p>
            )}
          </div>
        </div>
      </section>

      {/* ==================== WHY CHOOSE US ==================== */}
      <section className="py-16 sm:py-20" aria-labelledby="why-heading">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <div className="relative">
              <div className="absolute -left-4 -top-4 h-full w-full rounded-3xl bg-gradient-to-br from-teal/15 to-medblue/10" aria-hidden />
              <img
                src="/images/about-centre.jpg"
                alt="Representative view of a modern neighbourhood diagnostic centre"
                className="relative aspect-[4/3] w-full rounded-3xl object-cover shadow-xl shadow-navy/10"
                loading="lazy"
              />
              <div className="glass-card absolute -bottom-5 left-6 right-6 flex items-center gap-3 rounded-2xl p-4 sm:left-8 sm:right-auto">
                <LogoMark className="h-9 w-9 shrink-0" />
                <div>
                  <p className="text-[13px] font-extrabold text-navy">{settings.businessName}</p>
                  <p className="text-[11.5px] text-inkmuted">Uthalsar Naka, Thane West</p>
                </div>
              </div>
            </div>
          </Reveal>
          <div>
            <Reveal>
              <p className="eyebrow">Why Choose Us</p>
              <h2 id="why-heading" className="mt-2 text-3xl font-extrabold tracking-tight text-navy sm:text-[2.1rem]">
                A diagnostic partner your family can rely on
              </h2>
            </Reveal>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {whyItems.map((item, i) => (
                <Reveal key={item.title} delay={i * 0.07}>
                  <div className="h-full rounded-2xl border border-brandborder bg-white p-5 transition-colors hover:border-teal/50">
                    <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal/10 text-sm font-extrabold text-teal">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <h3 className="mt-3 text-[14.5px] font-extrabold text-navy">{item.title}</h3>
                    <p className="mt-1.5 text-[13px] leading-relaxed text-inkmuted">{item.description}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ==================== 3D SCIENCE SHOWCASE ==================== */}
      <section className="relative overflow-hidden bg-navy py-16 text-white sm:py-24" aria-labelledby="science-heading">
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(45% 40% at 80% 20%, rgba(23,182,164,0.25) 0%, transparent 60%), radial-gradient(40% 45% at 10% 85%, rgba(8,126,164,0.3) 0%, transparent 60%)",
          }}
          aria-hidden
        />
        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="order-2 lg:order-1">
            <Reveal>
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-teal-soft">The Science of Diagnostics</p>
              <h2 id="science-heading" className="mt-2 text-3xl font-extrabold tracking-tight sm:text-[2.1rem]">
                {settings.homeTechHeading}
              </h2>
              <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-white/75">{settings.homeTechBody}</p>
            </Reveal>
            <div className="mt-8 space-y-4">
              {sciencePoints.map((p, i) => (
                <Reveal key={p.title} delay={i * 0.08}>
                  <div className="flex gap-4 rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur transition-colors hover:border-teal/40">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal/15">
                      <p.icon className="h-5.5 w-5.5 text-teal-soft" aria-hidden />
                    </div>
                    <div>
                      <h3 className="text-[14.5px] font-extrabold text-white">{p.title}</h3>
                      <p className="mt-0.5 text-[13px] leading-relaxed text-white/65">{p.text}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
          <Reveal className="order-1 lg:order-2" delay={0.1}>
            <div className="relative mx-auto w-full max-w-[520px]">
              <Lazy3D
                load={loadDnaShowcase}
                fallbackSrc="/images/og-image.jpg"
                fallbackAlt="Abstract DNA double-helix visualisation (static preview)"
                className="aspect-square w-full"
                minHeight={340}
                sceneProps={{ mobile: isMobile }}
                hint="Abstract scientific visualisation"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* ==================== APPOINTMENT CTA ==================== */}
      <section className="py-16 sm:py-20" aria-labelledby="cta-heading">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy via-[#0d4a7c] to-medblue p-8 text-white shadow-2xl shadow-navy/25 sm:p-12">
              <div
                className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-teal/25 blur-3xl"
                aria-hidden
              />
              <div
                className="pointer-events-none absolute -bottom-28 -left-16 h-72 w-72 rounded-full bg-medblue-light/25 blur-3xl"
                aria-hidden
              />
              <div className="relative flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-center">
                <div className="max-w-xl">
                  <h2 id="cta-heading" className="text-2xl font-extrabold leading-tight tracking-tight sm:text-3xl">
                    Take the Next Step Towards Better Health.
                  </h2>
                  <p className="mt-3 text-[15px] leading-relaxed text-white/80">
                    Request an appointment online and our team will call you back to confirm the slot, preparation and
                    any other details. Walk-ins are welcome during working hours.
                  </p>
                </div>
                <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row lg:flex-col xl:flex-row">
                  <Button
                    onClick={go("#/book-test")}
                    size="lg"
                    className="h-12 rounded-full bg-white px-7 text-[15px] font-extrabold text-navy shadow-lg transition-transform hover:scale-[1.03]"
                  >
                    <CalendarCheck className="mr-2 h-5 w-5" aria-hidden />
                    Request an Appointment
                  </Button>
                  <a
                    href={BUSINESS.phoneHref}
                    className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-white/35 px-6 text-[15px] font-bold text-white transition-colors hover:bg-white/10"
                  >
                    <Phone className="h-4.5 w-4.5" aria-hidden />
                    {settings.phone}
                  </a>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
