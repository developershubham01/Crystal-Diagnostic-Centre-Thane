"use client";

import { PagePlaceholder } from "./PagePlaceholder";

/** TODO(2): replace with full implementation. */
export function AdminPage() {
  return <PagePlaceholder title="Admin" />;
}
