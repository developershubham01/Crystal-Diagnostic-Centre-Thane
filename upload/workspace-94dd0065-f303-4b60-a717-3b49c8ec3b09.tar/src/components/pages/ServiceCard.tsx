"use client";

import { ArrowRight, CalendarCheck, Clock, Droplets } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useRouterStore } from "@/lib/store";
import type { ServiceDTO } from "@/lib/api-client";
import { formatPrice } from "./PageStates";

/** Card used in the ServicesPage grid — clicking anywhere navigates to detail. */
export function ServiceCard({ service }: { service: ServiceDTO }) {
  const navigate = useRouterStore((s) => s.navigate);

  const openDetail = () => navigate(`#/services/${service.slug}`);
  const book = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate("#/book-test");
  };

  return (
    <article
      onClick={openDetail}
      className="card-lift group flex h-full cursor-pointer flex-col rounded-2xl border border-brandborder bg-white p-5 text-left focus-within:ring-2 focus-within:ring-medblue"
      tabIndex={0}
      role="link"
      aria-label={`View details for ${service.name}`}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openDetail();
        }
      }}
    >
      <div className="flex items-start justify-between gap-3">
        <Badge className="rounded-full bg-soft text-[11px] font-bold text-medblue hover:bg-soft" variant="secondary">
          {service.category?.name ?? "Diagnostic Test"}
        </Badge>
        {service.featured && (
          <span className="rounded-full bg-teal/10 px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wide text-teal">
            Popular
          </span>
        )}
      </div>

      <h3 className="mt-3.5 text-[16.5px] font-extrabold leading-snug text-navy transition-colors group-hover:text-medblue">
        {service.name}
      </h3>

      {service.shortDescription && (
        <p className="mt-1.5 line-clamp-2 text-[13.5px] leading-relaxed text-inkmuted">{service.shortDescription}</p>
      )}

      {/* Sample type + turnaround mini row */}
      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[12.5px] font-medium text-inkmuted">
        <span className="inline-flex items-center gap-1.5">
          <Droplets className="h-3.5 w-3.5 text-medblue" aria-hidden />
          {service.sampleType || "Sample type: to be confirmed"}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5 text-teal" aria-hidden />
          {service.turnaroundTime || "Report time: to be confirmed"}
        </span>
      </div>

      <div className="mt-auto flex items-center justify-between gap-3 border-t border-brandborder/70 pt-4">
        <div>
          <span className="block text-[10.5px] font-bold uppercase tracking-wide text-inkmuted">Price</span>
          <span className="text-[15px] font-extrabold text-navy">{formatPrice(service.price, service.priceVisible)}</span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={book}
            className="h-9 rounded-full bg-gradient-to-r from-navy to-medblue px-3.5 text-[12.5px] font-bold text-white"
          >
            <CalendarCheck className="mr-1 h-3.5 w-3.5" aria-hidden />
            Book
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={(e) => {
              e.stopPropagation();
              openDetail();
            }}
            className="h-9 rounded-full border-brandborder px-3.5 text-[12.5px] font-bold text-navy"
          >
            View Details
            <ArrowRight className="ml-1 h-3.5 w-3.5" aria-hidden />
          </Button>
        </div>
      </div>
    </article>
  );
}
