"use client";

import { Eye, HeartHandshake, MapPin, Navigation, Phone, Target, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/site/Reveal";
import { Breadcrumbs, JsonLd, PageHero, breadcrumbSchema } from "@/components/site/Shared";
import { useRouterStore } from "@/lib/store";
import { useSettings } from "@/lib/hooks";
import { usePageMeta } from "@/lib/seo";
import { BUSINESS } from "@/lib/constants";
import { CheckList } from "./PageStates";

export function AboutPage() {
  const navigate = useRouterStore((s) => s.navigate);
  const { data: settings } = useSettings();
  usePageMeta(
    "About Us",
    `${settings.businessName} — a neighbourhood diagnostic centre at Uthalsar Naka, Thane West. Our mission, vision and patient care philosophy.`,
    "/about"
  );

  const crumbs = [{ label: "About Us" }];

  const medicalBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "MedicalBusiness",
    name: settings.businessName,
    telephone: BUSINESS.phoneHref.replace("tel:", ""),
    description: settings.footerAbout,
    address: {
      "@type": "PostalAddress",
      streetAddress: settings.address.split("\n").slice(0, 2).join(", "),
      addressLocality: "Thane",
      addressRegion: "Maharashtra",
      postalCode: "400601",
      addressCountry: "IN",
    },
  };

  return (
    <div className="bg-white">
      <JsonLd data={breadcrumbSchema(crumbs)} />
      <JsonLd data={medicalBusinessSchema} />

      <PageHero
        eyebrow="About Us"
        title={`Know ${settings.businessName}`}
        description={settings.aboutIntro}
      />

      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <Breadcrumbs items={crumbs} />

        {/* Mission / Vision cards */}
        <div className="grid gap-6 md:grid-cols-2">
          <Reveal>
            <section
              aria-labelledby="mission-heading"
              className="card-lift h-full rounded-2xl border border-brandborder bg-white p-6"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-medblue/10 to-teal/10 ring-1 ring-brandborder">
                <Target className="h-6 w-6 text-medblue" aria-hidden />
              </div>
              <h2 id="mission-heading" className="mt-4 text-xl font-extrabold text-navy">
                Our Mission
              </h2>
              <p className="mt-2.5 text-[14.5px] leading-relaxed text-inkmuted">{settings.aboutMission}</p>
            </section>
          </Reveal>
          <Reveal delay={0.08}>
            <section
              aria-labelledby="vision-heading"
              className="card-lift h-full rounded-2xl border border-brandborder bg-white p-6"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-teal/10 to-medblue/10 ring-1 ring-brandborder">
                <Eye className="h-6 w-6 text-teal" aria-hidden />
              </div>
              <h2 id="vision-heading" className="mt-4 text-xl font-extrabold text-navy">
                Our Vision
              </h2>
              <p className="mt-2.5 text-[14.5px] leading-relaxed text-inkmuted">{settings.aboutVision}</p>
            </section>
          </Reveal>
        </div>

        {/* Patient Care Philosophy + image */}
        <div className="mt-14 grid items-center gap-10 lg:grid-cols-2">
          <Reveal>
            <div>
              <p className="eyebrow">Patient Care Philosophy</p>
              <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-navy sm:text-[1.8rem]">
                Diagnostics is a human service first
              </h2>
              <p className="mt-4 text-[15px] leading-relaxed text-inkmuted">{settings.aboutPhilosophy}</p>
              <div className="mt-6 flex items-start gap-3 rounded-2xl border border-brandborder bg-soft p-4">
                <HeartHandshake className="mt-0.5 h-5 w-5 shrink-0 text-medblue" aria-hidden />
                <p className="text-[13px] leading-relaxed text-inkmuted">
                  Have a question before your visit? Our front-desk team is happy to help —{" "}
                  <a href={BUSINESS.phoneHref} className="font-bold text-medblue underline-offset-2 hover:underline">
                    call {settings.phone}
                  </a>
                  .
                </p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <figure>
              <div className="relative">
                <div
                  className="absolute -left-4 -top-4 h-full w-full rounded-3xl bg-gradient-to-br from-teal/15 to-medblue/10"
                  aria-hidden
                />
                <img
                  src="/images/about-centre.jpg"
                  alt="Representative view of a modern neighbourhood diagnostic centre"
                  className="relative aspect-[4/3] w-full rounded-3xl object-cover shadow-xl shadow-navy/10"
                  loading="lazy"
                />
              </div>
              <figcaption className="mt-3 text-center text-[11.5px] italic leading-relaxed text-inkmuted">
                Representative image — to be replaced with photographs of the centre.
              </figcaption>
            </figure>
          </Reveal>
        </div>

        {/* Facilities + Quality checklists */}
        <div className="mt-14 grid gap-6 md:grid-cols-2">
          <Reveal>
            <section
              aria-labelledby="facilities-heading"
              className="h-full rounded-2xl border border-brandborder bg-soft p-6"
            >
              <h2 id="facilities-heading" className="text-lg font-extrabold text-navy">
                Facilities at the Centre
              </h2>
              <p className="mt-1 text-[12.5px] text-inkmuted">As described by the centre. Details to be confirmed.</p>
              <div className="mt-4">
                <CheckList text={settings.aboutFacilities} />
              </div>
            </section>
          </Reveal>
          <Reveal delay={0.08}>
            <section
              aria-labelledby="quality-heading"
              className="h-full rounded-2xl border border-brandborder bg-soft p-6"
            >
              <h2 id="quality-heading" className="text-lg font-extrabold text-navy">
                Our Approach to Quality
              </h2>
              <p className="mt-1 text-[12.5px] text-inkmuted">
                Care practices followed at the centre. Process details to be confirmed by the centre.
              </p>
              <div className="mt-4">
                <CheckList text={settings.aboutQuality} />
              </div>
            </section>
          </Reveal>
        </div>

        {/* Location & contact strip */}
        <Reveal>
          <section
            aria-labelledby="location-heading"
            className="mt-14 overflow-hidden rounded-3xl border border-brandborder bg-white shadow-lg shadow-navy/5"
          >
            <div className="border-b border-brandborder bg-gradient-to-r from-navy to-medblue px-6 py-5 text-white sm:px-8">
              <h2 id="location-heading" className="text-lg font-extrabold">
                Visit Us
              </h2>
              <p className="mt-0.5 text-[13px] text-white/80">
                We are easy to reach from across Thane West, opposite Varad Hospital.
              </p>
            </div>
            <div className="grid gap-6 p-6 sm:grid-cols-2 sm:p-8 lg:grid-cols-3">
              <div>
                <h3 className="flex items-center gap-2 text-[13px] font-extrabold uppercase tracking-wide text-medblue">
                  <MapPin className="h-4 w-4" aria-hidden />
                  Address
                </h3>
                <address className="mt-2.5 whitespace-pre-line text-[14px] not-italic leading-relaxed text-ink">
                  {settings.address}
                </address>
              </div>
              <div>
                <h3 className="flex items-center gap-2 text-[13px] font-extrabold uppercase tracking-wide text-medblue">
                  <Phone className="h-4 w-4" aria-hidden />
                  Phone
                </h3>
                <a
                  href={BUSINESS.phoneHref}
                  className="mt-2.5 inline-block text-[15px] font-extrabold text-navy transition-colors hover:text-medblue"
                >
                  {settings.phone}
                </a>
                <h3 className="mt-5 flex items-center gap-2 text-[13px] font-extrabold uppercase tracking-wide text-medblue">
                  <Clock className="h-4 w-4" aria-hidden />
                  Working Hours
                </h3>
                <p className="mt-2.5 whitespace-pre-line text-[14px] leading-relaxed text-ink">{settings.workingHours}</p>
                <p className="mt-1.5 text-[11.5px] italic text-inkmuted">{settings.workingHoursNote}</p>
              </div>
              <div className="flex flex-col justify-center gap-3">
                <Button
                  onClick={() => window.open(BUSINESS.mapsDirections, "_blank", "noopener,noreferrer")}
                  className="h-12 rounded-full bg-gradient-to-r from-navy to-medblue text-[14px] font-bold text-white shadow-md shadow-navy/20"
                >
                  <Navigation className="mr-2 h-4.5 w-4.5" aria-hidden />
                  Get Directions
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate("#/contact")}
                  className="h-12 rounded-full border-medblue/40 text-[14px] font-bold text-navy hover:bg-soft"
                >
                  Contact Us
                </Button>
              </div>
            </div>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
