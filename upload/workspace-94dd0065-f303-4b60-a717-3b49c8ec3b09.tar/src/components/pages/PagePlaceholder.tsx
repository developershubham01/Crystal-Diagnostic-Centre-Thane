"use client";

import { Construction } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouterStore } from "@/lib/store";

export function PagePlaceholder({ title }: { title: string }) {
  const navigate = useRouterStore((s) => s.navigate);
  return (
    <section className="container flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent">
        <Construction className="h-7 w-7 text-teal" aria-hidden />
      </div>
      <h1 className="text-2xl font-extrabold text-navy">{title}</h1>
      <p className="max-w-md text-sm text-inkmuted">
        This section is being prepared. Please check back shortly.
      </p>
      <Button onClick={() => navigate("#/")} className="rounded-full bg-navy text-white">
        Back to Home
      </Button>
    </section>
  );
}
