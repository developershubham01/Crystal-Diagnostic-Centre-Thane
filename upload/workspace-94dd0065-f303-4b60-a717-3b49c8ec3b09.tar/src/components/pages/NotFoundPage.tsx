"use client";

import Link from "next/link";
import { Compass, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRouterStore } from "@/lib/store";
import { usePageMeta } from "@/lib/seo";

export function NotFoundPage() {
  const navigate = useRouterStore((s) => s.navigate);
  usePageMeta("Page Not Found", "The page you are looking for could not be found.");

  return (
    <section className="bg-radial-soft">
      <div className="container flex min-h-[70vh] flex-col items-center justify-center gap-6 py-20 text-center">
        <div className="relative">
          <div className="absolute inset-0 -z-10 animate-pulse rounded-full bg-teal/15 blur-2xl" aria-hidden />
          <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white shadow-lg shadow-navy/10 ring-1 ring-brandborder">
            <Compass className="h-10 w-10 text-medblue" aria-hidden />
          </div>
        </div>
        <div>
          <p className="eyebrow">Error 404</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-navy sm:text-4xl">
            This page seems to have wandered off
          </h1>
          <p className="mx-auto mt-3 max-w-md text-[15px] leading-relaxed text-inkmuted">
            The page you are looking for doesn&apos;t exist or may have moved. Let&apos;s get you back on track.
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <Button
            onClick={() => navigate("#/")}
            className="rounded-full bg-gradient-to-r from-navy to-medblue px-6 font-bold text-white"
          >
            Go to Homepage
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("#/services")}
            className="rounded-full border-brandborder font-bold text-navy"
          >
            Browse Services
          </Button>
          <a
            href="tel:+918828393955"
            className="inline-flex items-center gap-2 rounded-full border border-brandborder px-5 py-2.5 text-sm font-bold text-navy hover:bg-soft"
          >
            <Phone className="h-4 w-4 text-medblue" aria-hidden />
            Call the Centre
          </a>
        </div>
        <p className="text-xs text-inkmuted">
          Looking for something specific?{" "}
          <Link href="#/contact" onClick={(e) => { e.preventDefault(); navigate("#/contact"); }} className="font-semibold text-medblue underline-offset-2 hover:underline">
            Contact us
          </Link>{" "}
          and we&apos;ll help you out.
        </p>
      </div>
    </section>
  );
}
