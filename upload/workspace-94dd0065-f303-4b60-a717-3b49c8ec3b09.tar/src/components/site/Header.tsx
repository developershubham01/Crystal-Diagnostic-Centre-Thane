"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, Phone, CalendarCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { LogoHorizontal } from "@/components/brand/Logo";
import { useRoute, useRouterStore } from "@/lib/store";
import { useSettings } from "@/lib/hooks";
import { cn } from "@/lib/utils";

const NAV = [
  { label: "Home", route: "#/" },
  { label: "About Us", route: "#/about" },
  { label: "Services", route: "#/services" },
  { label: "Packages", route: "#/packages" },
  { label: "Gallery", route: "#/gallery" },
  { label: "FAQ", route: "#/faq" },
  { label: "Contact", route: "#/contact" },
];

export function Header() {
  const route = useRoute();
  const navigate = useRouterStore((s) => s.navigate);
  const { data: settings } = useSettings();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    // Close the drawer whenever navigation happens (incl. browser back/forward)
    const close = () => setOpen(false);
    window.addEventListener("hashchange", close);
    return () => window.removeEventListener("hashchange", close);
  }, []);

  const isActive = (hash: string) => {
    const target = hash.replace("#/", "").replace("#", "");
    if (target === "") return route.name === "home";
    if (target === "services") return route.name === "services" || route.name === "service-detail";
    if (target === "packages") return route.name === "packages" || route.name === "package-detail";
    return route.name === target;
  };

  const go = (hash: string) => {
    setOpen(false);
    navigate(hash);
  };

  return (
    <header className="sticky top-0 z-50 w-full">
      <div
        className={cn(
          "w-full border-b transition-all duration-300",
          scrolled
            ? "border-brandborder bg-white/85 shadow-[0_8px_30px_-18px_rgba(11,59,102,0.35)] backdrop-blur-xl"
            : "border-transparent bg-white/60 backdrop-blur-md"
        )}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 md:h-[4.5rem] lg:px-8">
          {/* Logo */}
          <Link
            href="#/"
            onClick={(e) => {
              e.preventDefault();
              go("#/");
            }}
            aria-label="Crystal Diagnostic Centre — Home"
            className="shrink-0 rounded-lg outline-offset-4"
          >
            <LogoHorizontal showTagline={false} />
          </Link>

          {/* Desktop nav */}
          <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
            {NAV.map((item) => (
              <Link
                key={item.route}
                href={item.route}
                onClick={(e) => {
                  e.preventDefault();
                  go(item.route);
                }}
                aria-current={isActive(item.route) ? "page" : undefined}
                className={cn(
                  "rounded-full px-3.5 py-2 text-sm font-semibold transition-colors",
                  isActive(item.route)
                    ? "bg-accent text-navy"
                    : "text-inkmuted hover:bg-soft hover:text-navy"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <a
              href="tel:+918828393955"
              className="hidden items-center gap-2 rounded-full border border-brandborder px-3.5 py-2 text-sm font-bold text-navy transition-colors hover:bg-soft md:inline-flex"
            >
              <Phone className="h-4 w-4 text-medblue" aria-hidden />
              {settings.phone}
            </a>
            <Button
              onClick={() => go("#/book-test")}
              className="hidden rounded-full bg-gradient-to-r from-navy to-medblue px-4 py-2 text-sm font-bold text-white shadow-md shadow-navy/20 transition-transform hover:scale-[1.03] sm:inline-flex"
            >
              <CalendarCheck className="mr-1.5 h-4 w-4" aria-hidden />
              Book a Test
            </Button>

            {/* Mobile drawer */}
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full lg:hidden" aria-label="Open menu">
                  <Menu className="h-5 w-5 text-navy" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] border-brandborder bg-white p-0">
                <div className="flex items-center justify-between border-b border-brandborder p-4">
                  <LogoHorizontal showTagline={false} />
                  <button
                    onClick={() => setOpen(false)}
                    className="rounded-full p-2 text-inkmuted hover:bg-soft"
                    aria-label="Close menu"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <nav aria-label="Mobile" className="flex flex-col gap-1 p-4">
                  {NAV.map((item) => (
                    <button
                      key={item.route}
                      onClick={() => go(item.route)}
                      className={cn(
                        "rounded-xl px-4 py-3 text-left text-[15px] font-semibold transition-colors",
                        isActive(item.route) ? "bg-accent text-navy" : "text-ink hover:bg-soft"
                      )}
                    >
                      {item.label}
                    </button>
                  ))}
                  <div className="mt-3 space-y-2 border-t border-brandborder pt-4">
                    <Button
                      onClick={() => go("#/book-test")}
                      className="w-full rounded-xl bg-gradient-to-r from-navy to-medblue font-bold text-white"
                    >
                      <CalendarCheck className="mr-2 h-4 w-4" aria-hidden />
                      Book a Test
                    </Button>
                    <Button
                      onClick={() => go("#/reports")}
                      variant="outline"
                      className="w-full rounded-xl font-bold text-navy"
                    >
                      Report Access
                    </Button>
                    <a
                      href="tel:+918828393955"
                      className="flex items-center justify-center gap-2 rounded-xl border border-brandborder py-2.5 text-sm font-bold text-navy"
                    >
                      <Phone className="h-4 w-4 text-medblue" aria-hidden /> {settings.phone}
                    </a>
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
