"use client";

import { ChevronRight, Home } from "lucide-react";
import { useRouterStore, type Route } from "@/lib/store";

export interface Crumb {
  label: string;
  route?: string; // hash route; omit for current page (non-link)
}

/** Breadcrumb navigation with BreadcrumbList schema rendered by the page. */
export function Breadcrumbs({ items }: { items: Crumb[] }) {
  const navigate = useRouterStore((s) => s.navigate);
  return (
    <nav aria-label="Breadcrumb" className="mb-4">
      <ol className="flex flex-wrap items-center gap-1 text-[12.5px]">
        <li>
          <button
            onClick={() => navigate("#/")}
            className="inline-flex items-center gap-1 font-semibold text-inkmuted transition-colors hover:text-medblue"
          >
            <Home className="h-3.5 w-3.5" aria-hidden />
            Home
          </button>
        </li>
        {items.map((item, i) => (
          <li key={i} className="flex items-center gap-1">
            <ChevronRight className="h-3.5 w-3.5 text-brandborder" aria-hidden />
            {item.route ? (
              <button
                onClick={() => navigate(item.route!)}
                className="font-semibold text-inkmuted transition-colors hover:text-medblue"
              >
                {item.label}
              </button>
            ) : (
              <span aria-current="page" className="font-bold text-navy">
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

/** Shared inner-page hero band with soft medical background. */
export function PageHero({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  children?: React.ReactNode;
}) {
  return (
    <section className="bg-radial-soft relative overflow-hidden border-b border-brandborder">
      <div
        className="bg-med-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(70%_80%_at_50%_0%,black,transparent)]"
        aria-hidden
      />
      <div className="relative mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-2 max-w-3xl text-3xl font-extrabold tracking-tight text-navy sm:text-4xl">{title}</h1>
        {description && <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-inkmuted">{description}</p>}
        {children}
      </div>
    </section>
  );
}

/** JSON-LD injector for structured data (client-side). */
export function JsonLd({ data }: { data: Record<string, unknown> }) {
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function breadcrumbSchema(items: Crumb[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: "/" },
      ...items.map((c, i) => ({ "@type": "ListItem", position: i + 2, name: c.label })),
    ],
  };
}

export type { Route };
